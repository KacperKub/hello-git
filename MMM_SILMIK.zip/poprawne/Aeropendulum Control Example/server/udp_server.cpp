#include <iostream>
#include <sstream>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include "datetimestr.h"
#include "udp_parse_args.h"

#define DEFAULT_IP "172.27.229.191"
#define DEFAULT_PORT 20000
#define MAXLINE 1024

struct options
{
  bool flag_a;
  bool flag_b;
  double value_c;
  bool flag_h;
  options() : flag_a(false), flag_b(false), value_c(0.0), flag_h(false) {}
};

void cstr_to_tok(const char *str, int *tok_cnt, char **tok_vec, int tok_cnt_max)
{
  int count = 0;
  const char *delim = " ";
  char *temp_str = strdup(str); // Tworzymy tymczasową kopię stringa, ponieważ strtok modyfikuje oryginał
  char *token = strtok(temp_str, delim);

  while (token != NULL && count < tok_cnt_max)
  {
    tok_vec[count] = strdup(token); // Kopiujemy tokeny
    count++;
    token = strtok(NULL, delim);
  }

  *tok_cnt = count; // Zapisujemy liczbę tokenów
  free(temp_str);   // Zwolnienie tymczasowej kopii
}

void abc_parse_args(char *command, options *op)
{
  const int argc_max = 32;
  int argc;
  char *argv[argc_max];

  cstr_to_tok(command, &argc, argv, argc_max);

  // Zakładając, że znasz format danych
  for (int i = 0; i < argc; ++i)
  {
    if (strcmp(argv[i], "a") == 0)
    {
      op->flag_a = true;
    }
    else if (strcmp(argv[i], "b") == 0)
    {
      op->flag_b = true;
    }
    else if (strcmp(argv[i], "c") == 0 && (i + 1 < argc))
    {
      op->value_c = atof(argv[i + 1]); // Przyjmij, że po 'c' zawsze następuje liczba
      i++;                             // Pomiń wartość po 'c'
    }
  }

  // Zwolnienie zarezerwowanej pamięci
  for (int i = 0; i < argc; ++i)
  {
    free(argv[i]);
  }
}

int main(int argc, char *argv[])
{
  struct argopt opt = {DEFAULT_PORT, DEFAULT_IP};
  udp_parse_args(argc, argv, &opt);

  int sockfd;
  char rx_buffer[MAXLINE] = {0};
  char tx_buffer[MAXLINE] = {0};
  struct sockaddr_in servaddr, cliaddr;

  if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
  {
    std::cerr << "socket creation failed";
    std::exit(EXIT_FAILURE);
  }

  std::memset(&servaddr, 0, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  servaddr.sin_port = htons(opt.port);
  servaddr.sin_addr.s_addr = inet_addr(opt.ip);

  if (bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr)) < 0)
  {
    std::cerr << "bind failed";
    std::exit(EXIT_FAILURE);
  }

  std::cout << "[C++] UDP server up and listening." << std::endl;
  while (1)
  {
    int len = sizeof(cliaddr);
    recvfrom(sockfd, (char *)rx_buffer, MAXLINE, 0, (struct sockaddr *)&cliaddr, (socklen_t *)&len);
    std::cout << "Client message [" << datetimestr() << "]: " << rx_buffer << std::endl;

    options op;
    abc_parse_args(rx_buffer, &op);

    std::ostringstream oss;
    oss << "Options: a=" << op.flag_a
        << ", b=" << op.flag_b
        << ", c=" << op.value_c << std::endl;

    if (op.flag_h)
      oss << std::endl
          << "Usage: app [options]" << std::endl
          << "Options:" << std::endl
          << "-h            Display help message." << std::endl
          << "-a            [TODO]" << std::endl
          << "-b            [TODO]" << std::endl
          << "-c <numeric>  [TODO]" << std::endl;

    /* if (op.flag_a)
    {
      std::string text;
      text << "Measured speed:" << speed;
      std::strcpy(tx_buffer, text);
    }*/

    /* if (op.flag_a)
  {
    std::string text;
    text << "Measured speed:" << speed;
    std::strcpy(tx_buffer, text);
  }*/

    /* if (value c==-1)
    {
      stop silnik
    }
    else
    predkosc silnika =c
  {
    std::string text;
    text << "Measured speed:" << speed;
    std::strcpy(tx_buffer, text);
  }*/

    std::strcpy(tx_buffer, "Wesoło wysyłam dane");
    std::cout << std::endl;
    std::cout << "A:" << op.flag_a << std::endl;
    std::cout << "B:" << op.flag_b << std::endl;
    std::cout << "C:" << op.value_c << std::endl;
    sendto(sockfd, (const char *)tx_buffer, strlen(tx_buffer), 0, (const struct sockaddr *)&cliaddr, len);
    std::cout << "Response sent." << std::endl;
  }

  return 0;
}
